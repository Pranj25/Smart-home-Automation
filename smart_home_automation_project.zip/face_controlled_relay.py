import cv2
import numpy as np
import RPi.GPIO as GPIO
from picamera2 import Picamera2
import time

# Load Haar Cascade for Face Detection
face_cascade = cv2.CascadeClassifier("/home/pi/Downloads/haarcascade_frontalface_default.xml")

# Initialize Picamera2
picam2 = Picamera2()
config = picam2.create_preview_configuration(main={"size": (640, 480)})
picam2.configure(config)
picam2.start()

# Set up GPIO for Relay Control (Negative Logic)
GPIO.setmode(GPIO.BCM)  # Use BCM numbering
relay_pins = [17, 27, 22]  # GPIO pins connected to the relay
for pin in relay_pins:
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.HIGH)  # Ensure relays are OFF at the start (HIGH = OFF)

face_detected_prev = False  # To track state changes

try:
    while True:
        # Capture frame from camera
        frame = picam2.capture_array()

        # Convert to grayscale for better face detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces in the frame
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        if len(faces) > 0:
            if not face_detected_prev:  # Only print when state changes
                print("Face Detected - Turning ON Relays")
            face_detected_prev = True
            for pin in relay_pins:
                GPIO.output(pin, GPIO.LOW)  # LOW = ON for negative logic
        else:
            if face_detected_prev:  # Only print when state changes
                print("No Face Detected - Turning OFF Relays")
            face_detected_prev = False
            for pin in relay_pins:
                GPIO.output(pin, GPIO.HIGH)  # HIGH = OFF

        # Draw rectangles around detected faces
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

        # Display the live video with face detection
        cv2.imshow("Face Detection - Press 'q' to Exit", frame)

        # Press 'q' to exit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        time.sleep(0.1)  # Small delay to reduce unnecessary GPIO toggling

except KeyboardInterrupt:
    print("Program Stopped by User")

finally:
    # Cleanup
    cv2.destroyAllWindows()
    picam2.stop()
    GPIO.cleanup()  # Reset GPIO states
