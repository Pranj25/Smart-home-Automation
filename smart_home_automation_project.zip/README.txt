Smart Home Automation - Face Controlled Relay System

Files:
- face_controlled_relay.py: Main Python script that uses a PiCamera2 and Haar cascade for face detection to control relays.
- Requires: OpenCV, NumPy, RPi.GPIO, PiCamera2, and Haar Cascade XML file.

Usage:
1. Connect relays to GPIO 17, 27, and 22 on Raspberry Pi.
2. Ensure 'haarcascade_frontalface_default.xml' is placed in /home/pi/Downloads/.
3. Run the script using: python3 face_controlled_relay.py
4. The system will turn ON relays when a face is detected and OFF when no face is found.
